<?php

echo $userpro_social->follow_text($user_id);